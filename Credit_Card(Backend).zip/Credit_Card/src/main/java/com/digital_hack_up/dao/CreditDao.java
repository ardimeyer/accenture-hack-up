package com.digital_hack_up.dao;

import java.util.List;

import com.digital_hack_up.dto.CreditCardDTO;

public interface CreditDao {
   public List<CreditCardDTO> getDataEducationVsLimitBal();
}
